Los archivos fueron compilados con la linea:
g++ -Wall main.cpp Torneo.cpp Equipo.cpp -o MAIN

*Si la entrada en el main es 3, el programa no recibe el input de poder_preguntado en la misma linea.

